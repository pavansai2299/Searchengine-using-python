# Searchengine-using-compound-splitter


A Trie datastructure is used to store all the words (other that stopwords) in the documents. When we give compound queries for example "Whatistheshapeofearth" we split the query removing the stopwords. Our remaining query will be "shape earth". then we retrieve the documents rankwise using cosine similarity   


We need python3 to run this code
create some dummy documents having names "1.txt", "2.txt" etc.
